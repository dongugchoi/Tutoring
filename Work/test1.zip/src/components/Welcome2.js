export default function Welcome2({city, population}){
    return(
        <>
            <p>Welcome to {city} (인구 수 : {population}만 명 )</p>
        </>
    )
}